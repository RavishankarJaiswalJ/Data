package test;

import java.awt.Dimension;

import org.openqa.selenium.WindowType;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.CapabilitiesUtils;
//import org.openqa.selenium.Dimension;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Browser {
		public static void main(String[] args) throws InterruptedException {
			System.setProperty("webdriver.chrome.driver", "C:/Driver/chromedriver.exe");
//			WebDriverManager.chromedriver().setup();
			ChromeOptions options = new ChromeOptions();
			ChromeOptions co = new ChromeOptions();
			co.addArguments("--remote-allow-origins=*");
			options.addArguments("--proxy-server=http://localhost:4200");
			ChromeDriver driver = new ChromeDriver(co);
//			ChromeDriver driver = new ChromeDriver();
			
			driver.get("https://w3schools.com/");
			String originalwindow = driver.getWindowHandle();
			driver.navigate().to("https://www.selenium.dev/");
			driver.manage().window().maximize();
			Thread.sleep(5000);
			driver.navigate().back();
			Thread.sleep(5000);
			driver.navigate().forward();
			Thread.sleep(5000);
			driver.navigate().refresh();
			
			driver.switchTo().window(originalwindow);
			Thread.sleep(5000);
			driver.switchTo().newWindow(WindowType.WINDOW);
			driver.switchTo().newWindow(WindowType.TAB);
			driver.manage().window().getSize().getWidth();
			driver.manage().window().getSize().getHeight();
			org.openqa.selenium.Dimension size = driver.manage().window().getSize();
			System.out.println(size.getWidth());
			System.out.println(size.getHeight());
//			CapabilitiesUtils.setCapability("screenResolution", "1920x1080");
//			driver.manage().window().setSize(new Dimension(800,600));
			
//			driver.close();
		}
}
