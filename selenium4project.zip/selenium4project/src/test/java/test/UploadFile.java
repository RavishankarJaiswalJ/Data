package test;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

import io.github.bonigarcia.wdm.WebDriverManager;

public class UploadFile {
	public static void main(String[] args) throws InterruptedException {
//		System.setProperty("webdriver.chrome.driver", "C:/Driver/chromedriver.exe");
		WebDriverManager.chromedriver().setup();
//		ChromeOptions options = new ChromeOptions();
		ChromeOptions co = new ChromeOptions();
		co.addArguments("--remote-allow-origins=*");
		co.addArguments("--start-maximized");
//		options.addArguments("--proxy-server=http://localhost:4200");
		ChromeDriver driver = new ChromeDriver(co);
//		ChromeDriver driver = new ChromeDriver();
		
		driver.get("https://google.com/");
		org.openqa.selenium.WebElement Add = driver.findElement(By.xpath("//textarea[@name=\"q\"]"));
		Add.sendKeys("gmail",Keys.ENTER);
		Thread.sleep(2000);
		driver.findElement(By.xpath("//a[@href=\"https://mail.google.com/?\"]")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//a[text()=\"Sign in\"]")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@name=\"identifier\"]")).sendKeys("ravishankarj010203@gmail.com");
		Thread.sleep(2000);
		driver.findElement(By.xpath("//span[text()=\"Next\"]")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@name=\"Passwd\"]")).sendKeys("################");
		Thread.sleep(2000);
		driver.findElement(By.xpath("//span[text()=\"Next\"]")).click();
		Thread.sleep(5000);
		driver.findElement(By.xpath("//div[text()=\"Compose\"]")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@id=\":tm\"]")).sendKeys("ravishankarj786gmail.com");
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@name=\"subjectbox\"]")).sendKeys("Automation Testing");
		Thread.sleep(2000);
		driver.findElement(By.xpath("//div[@aria-label=\"Message Body\"]")).sendKeys("Hi Ravi,This is automation Testing");
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@type=\"file\"]")).sendKeys("src/test/resources/Ravi_resume_v1.0");
		Thread.sleep(2000);
		driver.findElement(By.xpath("//div[text()=\"Send\"]")).click();
		Thread.sleep(8000);
		driver.close();
		driver.quit();
		
	}


}
