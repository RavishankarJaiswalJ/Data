package test;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Alert {
	public static void main(String[] args) throws InterruptedException {
		WebDriverManager.chromedriver().setup();
		ChromeOptions options = new ChromeOptions();
		ChromeOptions co = new ChromeOptions();
		co.addArguments("--remote-allow-origins=*");
		options.addArguments("--proxy-server=http://localhost:4200");
		ChromeDriver driver = new ChromeDriver(co);
//		ChromeDriver driver = new ChromeDriver();
		driver.get("https://trytestingthis.netlify.app/index.html");
		driver.manage().window().maximize();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//h1[contains(text(),\"Your Website to practice \")]")).isDisplayed();
		org.openqa.selenium.WebElement Alert = driver.findElement(By.xpath("//button[text()=\" Your Sample Alert Button!\"]"));
		Alert.click();
		Thread.sleep(2000);
//		driver.switchTo().alert().dismiss();
		driver.switchTo().alert().accept();
		Thread.sleep(5000);
		driver.close();
		driver.quit();
		
	}

}
