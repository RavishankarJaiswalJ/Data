package test;

import java.awt.RenderingHints.Key;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

import io.github.bonigarcia.wdm.WebDriverManager;

public class WebElement {
	public static void main(String[] args) throws InterruptedException {
//		System.setProperty("webdriver.chrome.driver", "C:/Driver/chromedriver.exe");
		WebDriverManager.chromedriver().setup();
		ChromeOptions options = new ChromeOptions();
		ChromeOptions co = new ChromeOptions();
		co.addArguments("--remote-allow-origins=*");
		options.addArguments("--proxy-server=http://localhost:4200");
		ChromeDriver driver = new ChromeDriver(co);
//		ChromeDriver driver = new ChromeDriver();
		
		driver.get("https://google.com/");
		driver.manage().window().maximize();
		Thread.sleep(2000);
//		driver.findElement(By.name("q")).sendKeys("w3school.com"));
//		org.openqa.selenium.WebElement serchbox = driver.findElement(By.name("q"));
//		serchbox.sendKeys("ABCD",Keys.ENTER);
		
		driver.navigate().to("https://trytestingthis.netlify.app/");
		List<org.openqa.selenium.WebElement> options1 = driver.findElements(By.name("Optionwithcheck[]"));
		
		for(org.openqa.selenium.WebElement element : options1) {
			System.out.println(element.getText());
		}
		driver.findElement(By.cssSelector("#fname")).sendKeys("Ravi");
		driver.findElement(By.xpath("//input[@id=\"lname\"]")).click();
		driver.findElement(By.xpath("//input[@id=\"lname\"]")).sendKeys("Jaiswal");
		org.openqa.selenium.WebElement element = driver.findElement(By.xpath("//h2[text()=\"Created by Oviya Kandaswamy\"]"));
		driver.executeScript("arguments[0].scrollIntoView();", element);
		
		Thread.sleep(5000);
		
		driver.close();
		driver.quit();
		
	}


}
