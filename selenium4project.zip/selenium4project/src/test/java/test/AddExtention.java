package test;

import java.io.File;
import java.nio.file.Path;
import java.nio.file.Paths;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

import io.github.bonigarcia.wdm.WebDriverManager;

public class AddExtention {
	public static void main(String[] args) throws InterruptedException {
		WebDriverManager.chromedriver().setup();
		ChromeOptions options = new ChromeOptions();
		ChromeOptions co = new ChromeOptions();
		co.addArguments("--remote-allow-origins=*");
		Path path = Paths.get("src/test/resources/extension.crx");
        co.addExtensions(new File(path.toUri()));
//		co.addEncodedExtensions("../test.lib/extension.crx");
//		options.addArguments("--proxy-server=http://localhost:4200");
        co.addArguments("--start-maximized");
		ChromeDriver driver = new ChromeDriver(co);
//		ChromeDriver driver = new ChromeDriver();
		driver.get("https://www.google.com/");
		
//		driver.manage().window().maximize();
		Thread.sleep(2000);
//		driver.findElement(By.xpath("//h1[contains(text(),\"Your Website to practice \")]")).isDisplayed();
		org.openqa.selenium.WebElement Add = driver.findElement(By.xpath("//textarea[@name=\"q\"]"));
		Add.sendKeys("Chrome web store",Keys.ENTER);
		org.openqa.selenium.WebElement AddE = driver.findElement(By.xpath("//a[@href=\"https://chrome.google.com/webstore\"]"));
		AddE.click();
		driver.findElement(By.xpath("//input[@placeholder=\"Search the store\"]")).sendKeys("Ublock origin",Keys.ENTER);
		Thread.sleep(15000);
		driver.findElement(By.xpath("//div[text()=\"uBlock Origin\"]")).click();
		Thread.sleep(5000);
//		driver.findElement(By.xpath("(//div[text()=\"Add to Chrome\"])[1]")).click();
//		Thread.sleep(2000);
//		driver.switchTo().alert().accept();
//		Thread.sleep(2000);
		
		
		
		
		Thread.sleep(2000);
//		driver.switchTo().alert().dismiss();
//		driver.switchTo().alert().accept();
//		Thread.sleep(5000);
//		driver.close();
//		driver.quit();
		
	}

}
