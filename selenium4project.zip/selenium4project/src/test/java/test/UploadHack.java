package test;

import java.io.File;
import java.nio.file.Path;
import java.nio.file.Paths;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import io.github.bonigarcia.wdm.WebDriverManager;

public class UploadHack {
	public static void main(String[] args) throws InterruptedException {
//		System.setProperty("webdriver.chrome.driver", "C:/Driver/chromedriver.exe");
		WebDriverManager.chromedriver().setup();
		ChromeOptions co = new ChromeOptions();
		co.addArguments("--remote-allow-origins=*");
		co.addArguments("--start-maximized");
		ChromeDriver driver = new ChromeDriver(co);		
		driver.get("https://google.com/");
		org.openqa.selenium.WebElement Add = driver.findElement(By.xpath("//textarea[@name=\"q\"]"));
		Add.sendKeys("hackerrank",Keys.ENTER);
		Thread.sleep(2000);
		driver.findElement(By.xpath("(//a[@href=\"https://www.hackerrank.com/\"])[1]")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//a[text()=\"Log in\"]")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("(//a[text()=\"Login\"])[2]")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@placeholder=\"Your username or email\"]")).sendKeys("ravishankarj786@gmail.com");
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@placeholder=\"Your password\"]")).sendKeys("Ravi@hack786");
		Thread.sleep(2000);
		driver.findElement(By.xpath("//span[text()=\"Log In\"]")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//span[text()=\"Certify\"]")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//span[text()=\"SQL (Basic)\"]")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("(//span[text()=\"Take the HackerRank Skills Test\"])[1]")).click();
		Thread.sleep(2000);
		File file = new File("src/test/resources/Ravi_resume_v1.0.pdf");
		driver.findElement(By.xpath("//input[@type=\"file\"]")).sendKeys(file.getAbsolutePath());
		Thread.sleep(9000);
		driver.close();
		driver.quit();
	}

}

