package test;

import java.io.File;
import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

import io.github.bonigarcia.wdm.WebDriverManager;

public class CreateFile {
	public static void main(String[] args) throws InterruptedException, IOException {
//		System.setProperty("webdriver.chrome.driver", "C:/Driver/chromedriver.exe");
		WebDriverManager.chromedriver().setup();
		ChromeOptions options = new ChromeOptions();
		ChromeOptions co = new ChromeOptions();
		co.addArguments("--start-maximized");
		co.addArguments("--remote-allow-origins=*");
		ChromeDriver driver = new ChromeDriver(co);
		driver.get("https://w3schools.com/");
		Thread.sleep(5000);
		String text = driver.findElement(By.xpath("//h1[text()=\"Learn to Code\"]")).getText();
		System.out.println(text);
		File file = new File("src/test/resources/abcd.txt");
		file.createNewFile();
		
		driver.close();
		driver.quit();
		
	}


}
