package test;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

import io.github.bonigarcia.wdm.WebDriverManager;


public class FirstTest {
		public static void main(String[] args) throws InterruptedException {
			System.setProperty("webdriver.chrome.driver", "C:/Driver/chromedriver.exe");
//			WebDriverManager.chromedriver().setup();
			ChromeOptions options = new ChromeOptions();
			ChromeOptions co = new ChromeOptions();
			co.addArguments("--remote-allow-origins=*");
			options.addArguments("--proxy-server=http://localhost:4200");
			ChromeDriver driver = new ChromeDriver(co);
//			ChromeDriver driver = new ChromeDriver();
			
			driver.get("https://w3schools.com/");
			driver.manage().window().maximize();
			Thread.sleep(5000);
			
			driver.close();
			
		}

}
