var FirstName ="Ravishankar";

// String Indexing

console.log(FirstName.length);
// index value
// index start from 0 till end
// R a v i s h a n k a r
// 0 1 2 3 4 5 6 7 8 9 10
console.log(FirstName[3]);
// calling last index
console.log(FirstName[FirstName.length -1]);

// calling secound last index
console.log(FirstName[FirstName.length -2]);
