// if else condition

// let age =18;

// if(age>18){
//     console.log("User is eligible for vote");

// }
// else{
//     console.log("User is not eligible for vote");
// }

// let num =18;

// if(num%2===0){
//     console.log("even");

// }
// else{
//     console.log("odd");
// }

//falsy values
//false
// ""
// undefiend
// null
// 0

//////////////// this all are false values
// let num ;
// let num=0;
// let num=null;
// let num=undefined;
// let num="";

// ######################### truthy values ############
// let num =1;
let num ="string";
// let num =true;


if(num){
    console.log("num");

}
else{
    console.log("num is empty");
}