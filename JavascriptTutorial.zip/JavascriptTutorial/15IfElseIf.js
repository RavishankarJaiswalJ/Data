// if 
//else if
//else


let tempdegree =15;

if(tempdegree<0){
    console.log("extremely  cold outside");
}
else if(tempdegree<16){
    console.log("cold outside");
}
else if(tempdegree<25){
    console.log("wheather i okay");
}
else if(tempdegree<35){
    console.log("let go for swimming");
}
else if(tempdegree<45){
    console.log("turn on Ac");
}
else{
    console.log("too hot!!");
}
 

 

 

