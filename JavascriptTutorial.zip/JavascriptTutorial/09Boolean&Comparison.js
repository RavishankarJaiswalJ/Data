//boolean and comapision operators

//boolean 
// true or false

let num1 =23;
let num2 = 78;
console.log(num1<num2);
console.log(num1>num2);
console.log(num1<=num2);
console.log(num1>=num2);

// == vs ===
console.log(num1==num2);
// console.log(num1=num2);
console.log(num1 === num2);

// != vs !==
console.log(num1 !== num2);
console.log(num1 != num2);