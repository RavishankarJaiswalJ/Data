"use strict"
// variable

var FirstName="RAVIS";
console.log(FirstName);


// let Variable