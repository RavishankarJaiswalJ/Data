// string concatination

// let string1 ="Ravi";
// let string2 ="shankar";

// let fullName = string1 + " " + string2;

// console.log(fullName);

// example 2 converting string to number and adding

let string1 ="17";
let string2 ="20";

let fullName = +string1 + +string2;

console.log(fullName);
console.log(typeof fullName)