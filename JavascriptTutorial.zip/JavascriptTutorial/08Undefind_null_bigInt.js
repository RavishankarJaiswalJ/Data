// undefind
//null
//bigInt


// let FirstName;

// console.log(typeof  FirstName );

// var FirstName;

// console.log(typeof  FirstName, FirstName );


// const cannot be assign as a undefiend
// const FirstName= "harshit";

// console.log(typeof  FirstName, FirstName );

//null

// var FirstName=null;

// console.log(typeof  FirstName , FirstName);
// bug , error null shows object.


// bigint
let FirstName=BigInt(12);
// console.log(FirstName.MAX_SAFE_INTEGER);
console.log(typeof  FirstName , FirstName);
