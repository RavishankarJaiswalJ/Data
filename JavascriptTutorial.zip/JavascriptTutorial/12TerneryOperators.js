// ternary operators & contion operators

let age = 3;
let dring = age >= 10 ? "coffie":"milk";

console.log(dring);