// typeof  operator
//data type
//string "harshit"
// number 2,3,4,5,
// booleans 
//undefined
//null
//bigInt
//symbol

//
// let age = 23;
// let FirstName = "harshit";
// console.log(typeof age);
// console.log(typeof FirstName);

// convert to string of
// let age = 23;
// let FirstName = "harshit";
// console.log(typeof age);
// console.log(typeof FirstName);
// age = age + "";
// console.log(typeof age);
// console.log(typeof(age));

// type two method  string

// let age = 34;
// age = String(age);
// console.log(age);
// console.log(typeof age);

// convert to number
// let num = "34";
// console.log(num);
// console.log(typeof num);
// num = +"34";
// console.log(num);
// console.log(typeof num);


// type two method  number

// let num = "34";
// num = Number(num);
// console.log(num);
// console.log(typeof num);







