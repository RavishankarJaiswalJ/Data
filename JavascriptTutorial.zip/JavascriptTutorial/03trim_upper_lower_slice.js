//trim 
// toUppercase
// toLowercase
// slice


//trim 
// let FirstName = "    harshit   ";

// console.log(FirstName.length);
// console.log(FirstName);
// FirstName = FirstName.trim();
// console.log(FirstName);
// console.log(FirstName.length);


// ********** toUpperCase ***************
// let FirstName = "    harshit   ";

// FirstName = FirstName.toUpperCase();
// console.log(FirstName);

// ********** toUpperCase ***************
// let FirstName = "    HARSHIT   ";

// FirstName = FirstName.toLowerCase();
// console.log(FirstName);

// ********** slice ***************
// slice make one different string  by index value first indicate and and end index.
let FirstName = "HARSHIT";

FirstName = FirstName.slice(2,6);
console.log(FirstName);