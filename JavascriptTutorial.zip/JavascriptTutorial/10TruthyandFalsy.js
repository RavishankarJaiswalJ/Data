//truthy and falsy values

//falsy values
//false
// ""
// undefiend
// null
// 0