//template string
let age =23;
let FirstName = "harshit";


// let aboutMe = "my name is " + FirstName + "and my age is " + age ;
// console.log(aboutMe); 

let aboutMe = `my name is ${FirstName} and my age is ${age} `;
console.log(aboutMe); 
