// while loop
// let a=0;


// while(a<10){
//     console.log("Hello World !")
//     a++;
// }


// ########################## while loop Example ###############

let num = 10;
let total = 0;
let i=0;

while(i<=10){
    total +=i;
    i++; 
}
console.log(total)