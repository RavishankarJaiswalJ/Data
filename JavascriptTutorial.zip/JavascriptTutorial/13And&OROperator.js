//and or operators


// AND operators
// let firstName = "Harshit";
// let age = 22;

// if(firstName[0] ==="H" && age>18){
//     console.log("Your first name start with 'H' and above 18");
// }
// else{
//     console.log("invalid data");
// }


// ################## OR #####################

let firstName = "Harshit";
let age = 22;

if(firstName[0] ==="h" || age>18){
    console.log("Your first name start with 'H' and above 18");
}
else{
    console.log("invalid data");
}