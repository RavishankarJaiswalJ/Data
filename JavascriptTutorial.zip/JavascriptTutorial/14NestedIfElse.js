// Nested if else

// winning number 19

//19 number is your guest number
//17 to low
//20 to high

let winningNumner= 19;
//prompt always take a value in string 
// for convert to number use + symbol
let guessNumber = +prompt("guess number") ; 

if(guessNumber===winningNumner){
    console.log("You guss correct winning Number !!");

}else{
    if(guessNumber<winningNumner){
        console.log("Is too Low!!");

    }else{
        console.log("Is too High !!")
    
    }
}